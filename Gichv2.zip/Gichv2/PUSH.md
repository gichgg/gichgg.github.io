# How to push this to gichgg.github.io

I can't push for you — I have no GitHub credentials in this session, and I'd rather you
didn't paste a personal access token into a chat window. Two minutes of your own hands
and it's live.

**Before you do anything: the portfolio page has three placeholder cards with dead `#`
links.** If you push all four pages now, that page goes live as promises. Either finish
one artefact first, or push everything except `portfolio.html` and remove the nav link
to it for now.

---

## Option A — command line (recommended)

```bash
git clone https://github.com/gichgg/gichgg.github.io
cd gichgg.github.io

# copy the contents of this deploy folder over the clone, then:
git add -A
git commit -m "Narrow positioning to AI and analytics tooling for HR; new styling; noindex"
git push origin main
```

Live in about a minute at https://gichgg.github.io

## Option B — GitHub web interface

Go to the repo, use **Add file → Upload files**, drag in the contents of this folder,
keep the folder structure, and commit to `main`.

---

## What changed

| File | Change |
|---|---|
| `index.html` | Rewritten — single position, one CTA, stats, about, contact |
| `services.html` | Six services → three engagements, process, "when not to hire me" |
| `portfolio.html` | Eight aspirational items → three real slots (**still placeholders**) |
| `css/style.css` | Replaced with your new stylesheet |
| `js/main.js` | Replaced with the light/dark toggle |
| `robots.txt` | **New** — blocks search engines |
| `assets/` | Untouched. Your photo and hero illustration are unchanged. |

Nothing is deleted. The only files touched are the ones listed above.

## The noindex, and why it matters

Every page carries `<meta name="robots" content="noindex, nofollow">` and `robots.txt`
disallows everything. That was the deliberate choice: a credibility page you send to
people, not a shopfront that gets discovered while you're still at Career Connections.

Two things that will quietly undo it:

- Linking the site from your LinkedIn profile or a public post.
- Removing `robots.txt` later without also removing the meta tags, or vice versa.

If you decide to go public later, delete `robots.txt` **and** strip the robots meta tag
from all three pages. Until then, leave both.
